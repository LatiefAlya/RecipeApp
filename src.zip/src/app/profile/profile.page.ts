// import { Component, OnInit } from '@angular/core';
// import { SpoonacularService } from '../service/spoonacular.service';
// import { ActivatedRoute } from '@angular/router';

// @Component({
//   selector: 'profile',
//   templateUrl: './profile.page.html',
//   styleUrls: ['./profile.page.scss'],
// })
// export class ProfilePage implements OnInit {
//   userId: number;

//   constructor(private spoonacularService: SpoonacularService, private route: ActivatedRoute) { }

//   ngOnInit() {
//     this.route.paramMap.subscribe(params => {
//       this.userId = +params.get('id');
//       this.loadProfile(this.userId);
//     });

//     let profilePage = 'https://example.com/profile';
//     console.log(profilePage);
//   }

//   loadProfile(userId: number) {
//     // implement the logic to load the profile here
//   }
// }
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.page.html',
  styleUrls: ['./profile.page.scss'],
})
export class ProfilePagePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
