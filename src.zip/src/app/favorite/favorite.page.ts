import { Component, OnInit } from '@angular/core';
import { SpoonacularService } from '../service/spoonacular.service';


@Component({
  selector: 'app-favorite',
  templateUrl: './favorite.page.html',
  styleUrls: ['./favorite.page.scss'],
})
export class FavoritePage implements OnInit {

  recipes: [] = [];

  constructor(private spoonacular: SpoonacularService) { }

  ngOnInit() {
  }

  fetchRecipeDetail() {
    let id: number = 0;

    this.spoonacular.getDetailRecipe(id)
    .subscribe((data: any) => {
      this.recipes = data;
    }, (error: Error) => {
      console.error('Error fetching recipes:', error);
    });
  }

}
